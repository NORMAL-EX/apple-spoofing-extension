# Xdows Security 真相揭露网站

这是一个揭露 "Xdows Security" 杀毒软件项目真面目的静态网站。

## 主要发现

- **核心引擎缺失**: SouXiao 扫描引擎完全不存在
- **云查杀失效**: 两个云查杀服务全部不可用
- **性能问题**: 每 10ms 扫描进程，监控所有文件变化
- **安全隐患**: 要求管理员权限，可能误删文件
- **代码质量**: 大量空异常处理，抄袭代码

## 技术栈

- Next.js 15
- React 19
- Tailwind CSS v4
- TypeScript
- Lucide Icons

## 功能

- 深色/浅色主题切换
- 响应式设计
- 静态导出（可部署到任何静态托管服务）

## 开发

```bash
# 安装依赖
pnpm install

# 开发服务器
pnpm dev

# 构建
pnpm build

# 本地预览构建结果
pnpm start
```

## 部署

构建后的文件在 `out/` 目录，可以部署到：

- GitHub Pages
- Vercel
- Netlify
- Cloudflare Pages
- 任何静态托管服务

## 免责声明

本网站仅用于教育和安全研究目的，展示开源项目的安全审计结果。
