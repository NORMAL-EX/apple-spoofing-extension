"use client";

import { ThemeToggle } from "@/components/theme-toggle";
import {
  AlertTriangle,
  Bug,
  XCircle,
  TrendingDown,
  Shield,
  Cpu,
  Lock,
  Eye,
  Server,
  Code,
  CheckCircle2,
  MinusCircle
} from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center max-w-screen-xl mx-auto px-4">
          <div className="flex flex-1 items-center justify-between">
            <h1 className="text-xl font-bold">Xdows Security 真相</h1>
            <ThemeToggle />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-screen-xl mx-auto px-4 py-12 space-y-16">
        {/* Hero Section */}
        <section className="text-center space-y-4">
          <div className="inline-flex items-center justify-center p-4 bg-destructive/10 rounded-full mb-4">
            <AlertTriangle className="h-12 w-12 text-destructive" />
          </div>
          <h2 className="text-4xl font-bold tracking-tight">
            揭开 &quot;Xdows Security&quot; 的真面目
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            一个号称 &quot;下一代杀毒软件&quot; 的开源项目，实际上核心功能 100% 缺失
          </p>
          <div className="flex items-center justify-center gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1">
              <Code className="h-4 w-4" />
              完整代码分析
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Shield className="h-4 w-4" />
              安全警告
            </span>
          </div>
        </section>

        {/* Rating */}
        <section className="text-center">
          <div className="inline-block p-8 bg-destructive/10 border-2 border-destructive rounded-xl">
            <div className="text-6xl font-bold text-destructive mb-2">-20/10</div>
            <p className="text-sm text-muted-foreground">最终评分</p>
          </div>
        </section>

        {/* Main Issues */}
        <section className="space-y-8">
          <h3 className="text-3xl font-bold text-center">致命缺陷</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="p-6 border rounded-lg space-y-3 hover:border-destructive/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-destructive/10 rounded">
                  <XCircle className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-xl font-semibold">核心引擎缺失</h4>
              </div>
              <p className="text-muted-foreground">
                SouXiao 扫描引擎完全不存在，项目无法编译。README 承认：&quot;不开源相关内容，自行移除即可&quot;。
              </p>
              <div className="text-sm text-destructive font-mono">
                ❌ SouXiao_Self-Heuristic/: 文件不存在
              </div>
            </div>

            <div className="p-6 border rounded-lg space-y-3 hover:border-destructive/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-destructive/10 rounded">
                  <Server className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-xl font-semibold">云查杀全部失效</h4>
              </div>
              <p className="text-muted-foreground">
                两个云查杀服务全部不可用：103.118.245.82 返回 403，cv.szczk.top 被 Cloudflare 保护。
              </p>
              <div className="text-sm space-y-1">
                <div className="font-mono text-destructive">服务器 1: 403 Forbidden</div>
                <div className="font-mono text-destructive">服务器 2: Cloudflare 验证</div>
              </div>
            </div>

            <div className="p-6 border rounded-lg space-y-3 hover:border-yellow-500/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-yellow-500/10 rounded">
                  <Bug className="h-6 w-6 text-yellow-500" />
                </div>
                <h4 className="text-xl font-semibold">启发式检测极其简陋</h4>
              </div>
              <p className="text-muted-foreground">
                纯关键词匹配：文件名含 &quot;crack&quot; 就是病毒，使用 LoadLibrary API 就加分。
              </p>
              <div className="text-sm space-y-1">
                <div className="font-mono text-yellow-500">误报率: ~99%</div>
                <div className="font-mono text-yellow-500">检测率: ~1%</div>
              </div>
            </div>

            <div className="p-6 border rounded-lg space-y-3 hover:border-destructive/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-destructive/10 rounded">
                  <Cpu className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-xl font-semibold">性能灾难</h4>
              </div>
              <p className="text-muted-foreground">
                每 10ms 扫描一次进程列表，监控所有驱动器的所有文件变化。
              </p>
              <div className="text-sm font-mono text-destructive">
                CPU 占用: ~100% | 硬盘: 持续读写
              </div>
            </div>

            <div className="p-6 border rounded-lg space-y-3 hover:border-destructive/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-destructive/10 rounded">
                  <Lock className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-xl font-semibold">要求管理员权限</h4>
              </div>
              <p className="text-muted-foreground">
                app.manifest 强制要求管理员权限，可以删除任何文件、杀掉任何进程。
              </p>
              <div className="text-sm font-mono text-destructive">
                requireAdministrator: true
              </div>
            </div>

            <div className="p-6 border rounded-lg space-y-3 hover:border-destructive/50 transition-colors">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-destructive/10 rounded">
                  <Eye className="h-6 w-6 text-destructive" />
                </div>
                <h4 className="text-xl font-semibold">隐私泄露</h4>
              </div>
              <p className="text-muted-foreground">
                上传文件 MD5 到未知服务器，API Key 硬编码在代码中。
              </p>
              <div className="text-sm font-mono text-destructive">
                key=my_virus_key_2024 (已公开)
              </div>
            </div>
          </div>
        </section>

        {/* Code Quality */}
        <section className="space-y-6">
          <h3 className="text-3xl font-bold text-center">代码质量问题</h3>
          <div className="p-6 border rounded-lg space-y-4">
            <div className="flex items-start gap-3">
              <MinusCircle className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <h4 className="font-semibold mb-1">大量空异常处理</h4>
                <p className="text-sm text-muted-foreground">
                  到处都是 <code className="px-1.5 py-0.5 bg-muted rounded text-xs">try catch &#123;&#125;</code>，
                  吞掉所有错误，用户完全不知道发生了什么。
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MinusCircle className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <h4 className="font-semibold mb-1">抄袭代码</h4>
                <p className="text-sm text-muted-foreground">
                  Process.cs:19 注释：&quot;感谢 XiaoWeiSecurity...&quot; - 主动防御代码直接抄来的
                </p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <MinusCircle className="h-5 w-5 text-destructive mt-0.5" />
              <div>
                <h4 className="font-semibold mb-1">1064 行的单个 UI 文件</h4>
                <p className="text-sm text-muted-foreground">
                  SecurityPage.xaml.cs 包含所有业务逻辑，没有任何架构设计
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Evidence */}
        <section className="space-y-6">
          <h3 className="text-3xl font-bold text-center">关键证据</h3>
          <div className="grid md:grid-cols-2 gap-4">
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2 text-sm">缺失的核心引擎</h4>
              <code className="text-xs block overflow-x-auto">
                $ find . -name &quot;*SouXiao*&quot;<br />
                (空输出 - 文件根本不存在)
              </code>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2 text-sm">抄袭的代码</h4>
              <code className="text-xs block overflow-x-auto">
                // Protection/Process.cs:19<br />
                // 感谢 XiaoWeiSecurity...
              </code>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2 text-sm">硬编码 API Key</h4>
              <code className="text-xs block overflow-x-auto">
                key=my_virus_key_2024
              </code>
            </div>
            <div className="p-4 bg-muted rounded-lg">
              <h4 className="font-semibold mb-2 text-sm">管理员权限</h4>
              <code className="text-xs block overflow-x-auto">
                &lt;requestedExecutionLevel<br />
                &nbsp;&nbsp;level=&quot;requireAdministrator&quot;/&gt;
              </code>
            </div>
          </div>
        </section>

        {/* Capability Matrix */}
        <section className="space-y-6">
          <h3 className="text-3xl font-bold text-center">功能可用性</h3>
          <div className="overflow-x-auto">
            <table className="w-full border rounded-lg overflow-hidden">
              <thead className="bg-muted">
                <tr>
                  <th className="p-3 text-left">组件</th>
                  <th className="p-3 text-center">状态</th>
                  <th className="p-3 text-center">可用性</th>
                  <th className="p-3 text-center">危害</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                <tr>
                  <td className="p-3">UI 界面</td>
                  <td className="p-3 text-center">
                    <CheckCircle2 className="h-4 w-4 text-green-500 mx-auto" />
                  </td>
                  <td className="p-3 text-center">100%</td>
                  <td className="p-3 text-center text-muted-foreground">无</td>
                </tr>
                <tr>
                  <td className="p-3">SouXiao 引擎</td>
                  <td className="p-3 text-center">
                    <XCircle className="h-4 w-4 text-destructive mx-auto" />
                  </td>
                  <td className="p-3 text-center">0%</td>
                  <td className="p-3 text-center text-destructive">-</td>
                </tr>
                <tr>
                  <td className="p-3">云查杀 1</td>
                  <td className="p-3 text-center">
                    <XCircle className="h-4 w-4 text-destructive mx-auto" />
                  </td>
                  <td className="p-3 text-center">0%</td>
                  <td className="p-3 text-center text-destructive">泄露信息</td>
                </tr>
                <tr>
                  <td className="p-3">云查杀 2</td>
                  <td className="p-3 text-center">
                    <XCircle className="h-4 w-4 text-destructive mx-auto" />
                  </td>
                  <td className="p-3 text-center">0%</td>
                  <td className="p-3 text-center text-destructive">泄露信息</td>
                </tr>
                <tr>
                  <td className="p-3">本地检测</td>
                  <td className="p-3 text-center">
                    <TrendingDown className="h-4 w-4 text-yellow-500 mx-auto" />
                  </td>
                  <td className="p-3 text-center">10%</td>
                  <td className="p-3 text-center text-destructive">误删文件</td>
                </tr>
                <tr>
                  <td className="p-3">进程监控</td>
                  <td className="p-3 text-center">
                    <AlertTriangle className="h-4 w-4 text-yellow-500 mx-auto" />
                  </td>
                  <td className="p-3 text-center">50%</td>
                  <td className="p-3 text-center text-destructive">CPU 100%</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        {/* Conclusion */}
        <section className="text-center space-y-6 pb-12">
          <div className="max-w-3xl mx-auto space-y-4">
            <h3 className="text-3xl font-bold">结论</h3>
            <div className="p-6 bg-destructive/10 border-2 border-destructive rounded-xl space-y-3">
              <p className="text-lg">
                <strong>这不是一个杀毒软件，这是一个有害的空壳项目。</strong>
              </p>
              <ul className="text-left space-y-2 text-muted-foreground">
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                  <span>核心功能 100% 缺失，无法检测病毒</span>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                  <span>要求管理员权限，可能误删重要文件</span>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                  <span>性能问题严重，会拖垮系统</span>
                </li>
                <li className="flex items-start gap-2">
                  <XCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                  <span>上传文件信息到未知服务器，存在隐私风险</span>
                </li>
              </ul>
            </div>
            <div className="p-4 bg-yellow-500/10 border border-yellow-500/50 rounded-lg">
              <p className="text-sm font-semibold text-yellow-600 dark:text-yellow-500">
                ⚠️ 强烈建议不要使用此软件，也不要将其用于任何生产环境
              </p>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="text-center text-sm text-muted-foreground border-t pt-8">
          <p>
            本分析基于对 {" "}
            <a
              href="https://github.com/LoveProgrammingMint/Xdows-Security"
              target="_blank"
              rel="noopener noreferrer"
              className="underline hover:text-foreground"
            >
              Xdows-Security
            </a>
            {" "} 项目的完整代码审查
          </p>
          <p className="mt-2">仅用于教育和安全研究目的</p>
        </footer>
      </main>
    </div>
  );
}
