import type { Metadata } from "next";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";

export const metadata: Metadata = {
  title: "Xdows Security 真相揭露",
  description: "揭开 Xdows Security \"杀毒软件\"的真面目",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN" suppressHydrationWarning>
      <body className="font-sans antialiased">
        <ThemeProvider defaultTheme="system" storageKey="xdows-theme">
          {children}
        </ThemeProvider>
      </body>
    </html>
  );
}
