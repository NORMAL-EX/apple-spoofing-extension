﻿using System;

#nullable enable
namespace Self_Heuristic;

public readonly ref struct ExtractedBin
{
    internal readonly byte[]? _array;
    private readonly unsafe byte* _pointer;

    public unsafe ExtractedBin(byte[] array)
    {
        this._array = array;
        fixed (byte* numPtr = array)
            this._pointer = numPtr;
    }

    public unsafe ReadOnlySpan<byte> Data => new ReadOnlySpan<byte>((void*)this._pointer, 100352);
}
