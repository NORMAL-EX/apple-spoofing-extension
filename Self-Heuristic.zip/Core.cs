﻿#nullable enable
namespace Self_Heuristic;

public class Core
{
    private readonly FireUpModel UpModel;

    public Core(double Point, string CurrWorkingPath)
    {
        this.UpModel = new FireUpModel(Point, CurrWorkingPath + "\\SouXiao\\LiuLi.onnx");
    }

    public bool Run(string FilePath) => this.UpModel.RunLiuLiSuper(FilePath);
}
