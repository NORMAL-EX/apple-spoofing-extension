﻿using System;
using Microsoft.ML.OnnxRuntime;

#nullable enable
namespace Self_Heuristic;

internal sealed class LiuLiLoader : IDisposable
{
    private InferenceSession? _session;
    private string _modelPath;

    public LiuLiLoader(string modelPath)
    {
        this._modelPath = modelPath ?? throw new ArgumentNullException(nameof(modelPath));
        this.InitSession();
    }

    public void ReloadModel(string modelPath)
    {
        this._modelPath = modelPath ?? throw new ArgumentNullException(nameof(modelPath));
        this.DisposeSession();
        this.InitSession();
    }

    public InferenceSession GetSession()
    {
        return this._session ?? throw new InvalidOperationException("Session is not initialized.");
    }

    public void Dispose() => this.DisposeSession();

    private void InitSession()
    {
        if (this._session != null)
            return;
        try
        {
            SessionOptions options = new SessionOptions();
            options.AppendExecutionProvider_CUDA();
            options.GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_ALL;
            this._session = new InferenceSession(this._modelPath, options);
            Console.WriteLine("[LiuLiLoader] 使用 GPU 推理");
            return;
        }
        catch (Exception ex)
        {
            Console.WriteLine($"[LiuLiLoader] 加载 GPU 失败：{ex.Message}，即将回退 CPU");
        }
        this._session = new InferenceSession(
            this._modelPath,
            new SessionOptions() { GraphOptimizationLevel = GraphOptimizationLevel.ORT_ENABLE_ALL }
        );
        Console.WriteLine("[LiuLiLoader] 使用 CPU 推理");
    }

    private void DisposeSession()
    {
        this._session?.Dispose();
        this._session = (InferenceSession)null;
    }
}
