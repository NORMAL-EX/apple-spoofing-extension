﻿using System;
using Microsoft.ML.OnnxRuntime.Tensors;

#nullable enable
namespace Self_Heuristic
{
    public static class Normalize
    {
        private const int Side = 224;
        private const int Size = Side * Side;
        private const int OutLen = Size * 2;

        public static DenseTensor<float> ToOnnxTensor(ReadOnlySpan<byte> rawData)
        {
            if (rawData.Length != OutLen)
                throw new ArgumentException(
                    $"Raw data length {rawData.Length} does not match expected size {OutLen}."
                );

            var tensor = new DenseTensor<float>(new int[] { 1, 2, Side, Side });

            for (int i = 0; i < Size; i++)
            {
                tensor[0, 0, i / Side, i % Side] = rawData[i];
                tensor[0, 1, i / Side, i % Side] = rawData[i + Size];
            }

            return tensor;
        }
    }
}
