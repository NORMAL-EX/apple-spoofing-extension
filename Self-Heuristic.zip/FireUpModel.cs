﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.ML.OnnxRuntime;
using Microsoft.ML.OnnxRuntime.Tensors;

#nullable enable
namespace Self_Heuristic
{
    internal class FireUpModel
    {
        public double _Threshold;
        private LiuLiLoader _ModelLoder;

        private InferenceSession _ModelInferenceSession => this._ModelLoder.GetSession();

        public FireUpModel(double Threshold, string ModelPath)
        {
            this._Threshold = Threshold;
            this._ModelLoder = new LiuLiLoader(ModelPath);
            InferenceSession inferenceSession = this._ModelInferenceSession;
        }

        private static DenseTensor<float> ConvertToTensor(byte[] ByteArray)
        {
            if (ByteArray.Length != 128 * 128)
                throw new ArgumentException("ByteArray length must be 128 * 128 = 16384");

            var tensor = new DenseTensor<float>(new int[] { 1, 1, 128, 128 });

            for (int index = 0; index < ByteArray.Length; ++index)
            {
                int row = index / 128;
                int col = index % 128;

                if (row >= 128 || col >= 128)
                    throw new IndexOutOfRangeException(
                        $"Index out of range: row={row}, col={col}, i={index}"
                    );

                tensor[0, 0, row, col] = ByteArray[index] / 255.0f;
            }

            return tensor;
        }

        public static void ReadBytes(string path, byte[] buffer)
        {
            Array.Clear(buffer, 0, buffer.Length);
            using (
                FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read)
            )
            {
                int read;
                for (int offset = 0; offset < buffer.Length; offset += read)
                {
                    read = fs.Read(buffer, offset, buffer.Length - offset);
                    if (read == 0)
                        break;
                }
            }
        }

        public bool RunLiuLiSuper(string FilePath)
        {
            byte[] buffer = new byte[128 * 128];
            ReadBytes(FilePath, buffer);

            DenseTensor<float> tensor = ConvertToTensor(buffer);

            if (this._ModelInferenceSession == null)
                throw new InvalidOperationException("Inference session is not initialized.");

            var inputs = new List<NamedOnnxValue>
            {
                NamedOnnxValue.CreateFromTensor<float>("input", tensor),
            };

            using (var results = this._ModelInferenceSession.Run(inputs))
            {
                var outputTensor = results.First().AsTensor<float>();
                var outputList = outputTensor.ToArray().ToList();

                double maxLogit = outputList.Max();
                double sumExp = outputList.Sum(x => Math.Exp(x - maxLogit));
                var softmax = outputList.Select(x => Math.Exp(x - maxLogit) / sumExp).ToList();

                return softmax[1] > this._Threshold;
            }
        }
    }
}
