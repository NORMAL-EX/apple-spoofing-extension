﻿using System;
using System.Buffers;
using System.IO;
using System.Runtime.CompilerServices;
using PeNet;
using PeNet.Header.Pe;

#nullable enable
namespace Self_Heuristic;

internal class FeaturesExtraction
{
    public const int Side = 224;
    public const int Size = 50176;
    public const int OutLen = 100352;
    private readonly ArrayPool<byte> Pool = ArrayPool<byte>.Shared;

    public unsafe ExtractedBin Extract(string path)
    {
        byte[] array = (byte[])null;
        try
        {
            array = this.Pool.Rent(100352);
            fixed (byte* pointer = array)
            {
                using (FileStream fileStream = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    int num1 = fileStream.Read(new Span<byte>((void*)pointer, 50176));
                    if (num1 < 50176)
                        Unsafe.InitBlockUnaligned(
                            (void*)(pointer + num1),
                            (byte)0,
                            (uint)(50176 - num1)
                        );
                    try
                    {
                        PeFile peFile = new PeFile(path);
                        if (peFile.ImageSectionHeaders != null)
                        {
                            uint num2 = 50176;
                            foreach (
                                ImageSectionHeader imageSectionHeader in peFile.ImageSectionHeaders
                            )
                            {
                                if (
                                    (
                                        imageSectionHeader.Characteristics
                                        & ScnCharacteristicsType.CntCode
                                    ) != (ScnCharacteristicsType)0
                                )
                                {
                                    int pointerToRawData = (int)imageSectionHeader.PointerToRawData;
                                    int sizeOfRawData = (int)imageSectionHeader.SizeOfRawData;
                                    if (
                                        pointerToRawData >= 0
                                        && sizeOfRawData > 0
                                        && (long)(pointerToRawData + sizeOfRawData)
                                            <= fileStream.Length
                                    )
                                    {
                                        int length = (int)
                                            Math.Min((long)sizeOfRawData, (long)(100352U - num2));
                                        if (length > 0)
                                        {
                                            fileStream.Position = (long)pointerToRawData;
                                            int num3 = fileStream.Read(
                                                new Span<byte>((void*)(pointer + num2), length)
                                            );
                                            num2 += (uint)num3;
                                            if (num2 >= 100352U)
                                                break;
                                        }
                                        else
                                            break;
                                    }
                                }
                            }
                            if (num2 < 100352U)
                                Unsafe.InitBlockUnaligned(
                                    (void*)(pointer + num2),
                                    (byte)0,
                                    100352U - num2
                                );
                        }
                    }
                    catch { }
                }
            }
            return new ExtractedBin(array);
        }
        catch
        {
            if (array == null)
                array = this.Pool.Rent(100352);
            Array.Clear((Array)array, 0, 100352);
            return new ExtractedBin(array);
        }
    }

    public void FreeArray(ExtractedBin bin)
    {
        byte[] array = bin._array;
        if (array == null)
            return;
        this.Pool.Return(array);
    }
}
